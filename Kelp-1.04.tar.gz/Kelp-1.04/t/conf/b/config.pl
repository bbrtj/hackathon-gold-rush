{
    A => 'bar',
    B => 'foo'
};
