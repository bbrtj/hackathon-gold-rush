# This one will die because it does not return a HASH
[1,2,3]

# vim:syntax=perl
