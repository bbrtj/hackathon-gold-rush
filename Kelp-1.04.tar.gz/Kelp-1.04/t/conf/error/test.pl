{
    modules_init => {
        Template => {
            paths => [] # No error templates
        }
    }
}
