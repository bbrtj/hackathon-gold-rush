# This one will die for syntax error
{
    one => missing,
};
