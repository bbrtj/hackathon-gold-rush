package MyApp::Request;
use parent 'Kelp::Request';

# here just for testing

1;
