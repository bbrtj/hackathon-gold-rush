package MyApp2::Controller::Bar;
use Kelp::Base 'MyApp2::Controller';

sub test_inherit { "OK" }

1;
