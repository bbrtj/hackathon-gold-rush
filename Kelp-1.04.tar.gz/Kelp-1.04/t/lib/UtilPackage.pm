package UtilPackage;
use Exporter qw( import );

our @EXPORT = qw( path );

sub path { "OK" }

1;
