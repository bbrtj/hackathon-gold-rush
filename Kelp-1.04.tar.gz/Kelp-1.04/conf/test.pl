{
    # No Logger while testing
    "-modules" => ['Logger']
};
